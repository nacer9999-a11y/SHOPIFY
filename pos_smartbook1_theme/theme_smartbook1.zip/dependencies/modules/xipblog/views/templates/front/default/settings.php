<?php

// $xipblog_settings[] = array(
// 	'tinymce' => true,
//   	'legend' => array(
//   	'title' => $this->l('def Tab'),
//     ),
//     'input' => array(
//         array(
//         	'type' => 'textarea',
//         	'label' => $this->l('Custom CSS'),
//         	'name' => 'custsdfsfsfsom_css',
//         	'desc' => $this->l('Please Enter Your Custom CSS'),
//             'rows' => 30,
//             'cols' => 25,
//             'class' => "custom_csssss_class",
//         	'default_val' => '',
//         ),
//         array(
//         	'type' => 'textarea',
//         	'label' => $this->l('Custom JS'),
//         	'name' => 'sdfsfsfs',
//             'class' => "custom_jssss_class",
//             'desc' => $this->l('Please Enter Your Custom JS'),
//             'rows' => 30,
//             'cols' => 25,
//         	'default_val' => '',
//         )
//     ),
//     'submit' => array(
//         'title' => $this->l('Save'),
//         'class' => 'btn btn-default pull-right'
//     )
// );
